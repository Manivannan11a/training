import 'antd/dist/antd.css'; // or 'antd/dist/antd.less'
import './App.css';
// import Input from './component/input';
// import Button from './component/button/Button'

import Form from './component/form/Form';
import Card from './component/card/index';

function App() {
  return (
    <div className="App">
      <Form title="Login" subtitle="Form" />
      <Form title="Register" subtitle="Form" />
      <Form title="Test" subtitle="Form" />
      <Card title="hi this raja" content="royal mech"/>
      {/* <Card title="hi this ilayaraj"/>
      <Card title="hi this raj"/>
      <Card title="hi this ila"/>
      <Card title="hi this ilaya"/> */}
      
      
    </div>
  );
}

export default App;
