import Button from '../button/Button';
import './form.css';
import Input from '../input/input';

const Form = (props) => {

    const { title, subtitle } = props;

    const getMyName = () => {
        return `My Title ${title}`
    }

    return(
        <form>
            <h1>{getMyName()} {subtitle}</h1>
            <Input name="firstName" label="First Name" />
            <Input name="lastName" label="Last Name" />
            <Input name="email" label="Email" />
            {/* First Name: <input type="text" name="First Name" placeholder='First Name' />
            Last Name: <input type="text" name="Last Name" placeholder='Last Name Name'  />
            Email: <input type="text" name="Email" /> */}
            <Button btnText={title} />
        </form>
    )
}

export default Form;